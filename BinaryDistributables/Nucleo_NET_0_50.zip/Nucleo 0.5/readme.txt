Nucleo version 0.5
by Brian Mains

Included in the DLL is the Nucleo web forms, MVC, and MVP products.  The assemblies are as follows:

Web Forms
-------------
Nucleo.Web - for .NET 2.0 and above
Nucleo.web.WinFx -for .NET 3.5 and above

MVC
-------------
Nucleo.Web.Mvc - for ASP.NET MVC

MVP
------------
Nucleo.Web.Mvp - for MVP pattern implemented for web forms, .NET 3.5

Other general components
------------
Nucleo - Core set of general components for .NET 2.0 and above.
Nucleo.WinFx - Core components for .NET 3.5 and above.
Nucleo.Windows.WinFx - Components for windows/WPF .NET 3.5 and above (not fully developed)
Nucleo.GenericTesting - Useful testing components for TDD testing and such
Nucleo.NUnit and NUnit.Web - Testing components specific for NUnit; custom assertions and other helpers.


A separate document has been provided for documentation.  The document will be updated as I go.
Currently, most of my unit tests pass, but I am also working on strengthening the tests, using code
coverage, and adding features to the framework.

Please consult the EULA on the site for the latest documentation.