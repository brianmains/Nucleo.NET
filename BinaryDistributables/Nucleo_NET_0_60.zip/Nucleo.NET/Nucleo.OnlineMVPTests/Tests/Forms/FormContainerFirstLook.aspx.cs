﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using Nucleo.Web.Context.Services;


namespace Nucleo.Tests.Forms
{
	public partial class FormContainerFirstLook : System.Web.UI.Page
	{
		protected void Page_Load(object sender, EventArgs e)
		{
			var service = new MvpFormPostProcessingService();

			service.LoadValues(new 
			{ 
				Key = "TestKey", 
				Name = "TestName",
				BooleanValue = true,
				DateTimeValue = DateTime.Today,
				IntegerValue = DateTime.Today.Hour,
				StringValue = "This is some text"
			}, new FormPostProcessingOptions { Control = this.fc });

			this.btnSave.Click += new EventHandler(btnSave_Click);
		}

		void btnSave_Click(object sender, EventArgs e)
		{
			var service = new MvpFormPostProcessingService();
			this.lblOutput.Text = "The values saved were: ";
			var collection = service.GetValues(new FormPostProcessingOptions { Control = this.fc });

			foreach (var item in collection)
				this.lblOutput.Text += string.Format("{0}: {1};", item.Key, item.Value);

		}
	}
}