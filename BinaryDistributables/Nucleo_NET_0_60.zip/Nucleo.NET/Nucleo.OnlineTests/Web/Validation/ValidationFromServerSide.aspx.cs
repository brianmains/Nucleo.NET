﻿using System;
using System.ComponentModel.DataAnnotations;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using Nucleo.Validation;
using Nucleo.Validation.Settings;


namespace Nucleo.Web.Validation
{
	#region " Helper Classes "

	[DataAnnotatedInstance]
	public class TestClass
	{
		[
		Required(ErrorMessage = "Name is required"), 
		StringLength(50, ErrorMessage = "Name is too long")
		]
		public string Name { get; set; }

		[
		Required(ErrorMessage = "City is required"), 
		StringLength(50, ErrorMessage = "City is too long")
		]
		public string City { get; set; }

		[
		Required(ErrorMessage = "State is required"), 
		StringLength(50, ErrorMessage = "State is too long")
		]
		public string State { get; set; }
	}

	#endregion


	public partial class ValidationFromServerSide : Nucleo.Framework.TestPage
	{
		#region " Methods "

		protected override void OnLoad(EventArgs e)
		{
			base.OnLoad(e);

			
		}

		#endregion



		#region " Event Handlers "

		protected void btnSave_Click(object sender, EventArgs e)
		{
			TestClass obj = new TestClass
			{
				Name = this.txtName.Text,
				City = this.txtCity.Text,
				State = this.txtState.Text
			};

			ValidationManager manager = ValidationManager.Create(ConfigurationValidationSettings.Create());
			var session = manager.Validate(obj);

			this.valResults.LoadSession(session);
		}

		#endregion
	}
}
