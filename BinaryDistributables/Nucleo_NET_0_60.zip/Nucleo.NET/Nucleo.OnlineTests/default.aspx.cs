﻿using System;
using System.Web.UI;


namespace Nucleo
{
	public partial class DefaultPage : Page
	{
		
	}
}
