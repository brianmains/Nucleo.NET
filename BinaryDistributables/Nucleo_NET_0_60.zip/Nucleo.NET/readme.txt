------------------------------------------------------------------------
Nucleo.NET
Brian Mains

11/2/2010
------------------------------------------------------------------------

Included are the samples for web forms, MVC, and the Nucleo MVP framework.
DLL's built in debug and release mode.  Scripts embedded in the DLL.