﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Nucleo.Tests.DataSource
{
	public class TestClass
	{
		public int Key { get; set; }

		public string Name { get; set; }

		public int Region { get; set; }
	}
}