using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Mvc.Ajax;

namespace Nucleo.Controllers
{
    public class ElementsController : Controller
    {

        public ActionResult Form()
        {
            return View();
        }

    }
}
