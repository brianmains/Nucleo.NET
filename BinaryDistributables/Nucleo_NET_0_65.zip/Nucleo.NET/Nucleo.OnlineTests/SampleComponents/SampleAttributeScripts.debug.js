﻿/// <reference name="MicrosoftAjax.js" />
/// <reference name="MicrosoftAjaxTimer.debug.js" />
/// <reference name="MicrosoftAjaxWebForms.debug.js" />

Type.registerNamespace("Nucleo.SampleComponents");

Nucleo.SampleComponents.AttributedComponent = function() { }

Nucleo.SampleComponents.AttributedComponent.registerClass("Nucleo.SampleComponents.AttributedComponent");