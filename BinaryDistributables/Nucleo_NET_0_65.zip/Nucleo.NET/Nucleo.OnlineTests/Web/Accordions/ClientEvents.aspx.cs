﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Nucleo.Web.Accordions
{
	public partial class ClientEvents : Nucleo.Framework.TestPage
	{
		#region " Properties "

		protected override string Description
		{
			get { return "The accordion exposes a variety of events available to you."; }
		}

		#endregion
	}
}