Nucleo.NET
Brian Mains

Site: http://nucleo.codeplex.com
Documentation (in-process): http://cid-7ad307e4c39e56bd.office.live.com/browse.aspx/Nucleo

Blog: http://blogs.msmvps.com/bmains
Twitter: @brianmains

For online forum assistance, please use stackoverflow.com with the Nucleo tag.  I will do
my best to respond.  Additionally, you can use the discussions form on nucleo.codeplex.com.

Included in this are the following folders:
Binaries - the DLL's.
Nucleo.OnlineTests - Online tests of the Nucleo Web framework.
Nucleo.OnlineMVPTests - Online tests of the Nucleo MVP framework.
Nucleo.OnlineMVCTests - Online tests of the Nucleo MVC framework.

Web sites built on 4.0 framework, but the framework supports 3.5 and 4.0.